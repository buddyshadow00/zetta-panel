#!/bin/bash

# ==========================================
# ZETTA PANEL V1 - INSTALLATION SCRIPT
# Created by IamGunpoint
# ==========================================

# Bold Colors
CYAN="\033[1;36m"
BLUE="\033[1;34m"
GREEN="\033[1;32m"
PURPLE="\033[1;35m"
YELLOW="\033[1;33m"
WHITE="\033[1;37m"
RED="\033[1;31m"
RESET="\033[0m"

# Make sure we exit on errors but catch them gracefully
set -e
trap 'echo -e "\n${RED}❌ Installation failed! Please check the output above and ensure you run as root/sudo.${RESET}\n"; exit 1' ERR

echo -e "${BLUE}====================================================================${RESET}"
echo -e "${CYAN}"
echo "███████╗███████╗████████╗████████╗ █████╗ ██████╗  █████╗ ███╗   ██╗███████╗██╗     "
echo "╚══███╔╝██╔════╝╚══██╔══╝╚══██╔══╝██╔══██╗██╔══██╗██╔══██╗████╗  ██║██╔════╝██║     "
echo "  ███╔╝ █████╗     ██║      ██║   ███████║██████╔╝███████║██╔██╗ ██║█████╗  ██║     "
echo " ███╔╝  ██╔══╝     ██║      ██║   ██╔══██║██╔═══╝ ██╔══██║██║╚██╗██║██╔══╝  ██║     "
echo "███████╗███████╗   ██║      ██║   ██║  ██║██║     ██║  ██║██║ ╚████║███████╗███████╗"
echo "╚══════╝╚══════╝   ╚═╝      ╚═╝   ╚═╝  ╚═╝╚═╝     ╚═╝  ╚═╝╚═╝  ╚═══╝╚══════╝╚══════╝"
echo -e "${RESET}"
echo -e "${PURPLE}                  🚀 V1 Cloud Virtualization Engine 🚀                 ${RESET}"
echo -e "${WHITE}                          Made with ❤️ by IamGunpoint                 ${RESET}"
echo -e "${BLUE}====================================================================${RESET}\n"

# Verify root privileges
if [ "$EUID" -ne 0 ]; then
  echo -e "${RED}⚠️  Please run this installation script as root (sudo ./install.sh)${RESET}\n"
  exit 1
fi

echo -e "${YELLOW}⚡ Initializing ZettaPanel Setup...${RESET}\n"
sleep 1

# Function for displaying progress bars
show_progress() {
  local title="$1"
  local pct="$2"
  local bar="$3"
  echo -ne "\r${CYAN}🔄 ${title} ${WHITE}${bar} ${YELLOW}${pct}%${RESET}"
}

# STEP 1
show_progress "Updating Package Lists...       " "10" "[█.........]"
apt-get update -y > /dev/null 2>&1
show_progress "Updating Package Lists...       " "20" "[██........]"
echo -e "\r${GREEN}✅ Package Lists Updated!                                      ${RESET}"
sleep 0.5

# STEP 2
show_progress "Installing Python3 & Pip...     " "30" "[███.......]"
apt-get install python3 python3-pip python3-venv -y > /dev/null 2>&1
show_progress "Installing Python3 & Pip...     " "45" "[█████.....]"
echo -e "\r${GREEN}✅ Python3 & Pip Installed!                                    ${RESET}"
sleep 0.5

# STEP 3
show_progress "Checking Docker Environment...  " "55" "[██████....]"
if ! command -v docker > /dev/null 2>&1; then
  apt-get install docker.io -y > /dev/null 2>&1
  systemctl enable docker > /dev/null 2>&1 || true
  systemctl start docker > /dev/null 2>&1 || true
fi
show_progress "Checking Docker Environment...  " "70" "[███████...]"
echo -e "\r${GREEN}✅ Docker Virtualization Engine Configured!                   ${RESET}"
sleep 0.5

# STEP 4
show_progress "Installing Python Packages...   " "80" "[████████..]"
pip install -r requirements.txt > /dev/null 2>&1 || pip3 install -r requirements.txt --break-system-packages > /dev/null 2>&1 || true
show_progress "Installing Python Packages...   " "90" "[█████████.]"
echo -e "\r${GREEN}✅ Core Packages Installed Successfully!                      ${RESET}"
sleep 0.5

# STEP 5
show_progress "Configuring Environment...      " "95" "[█████████▉]"
if [ ! -f .env ]; then
  if [ -f env.properties ]; then
    cp env.properties .env
  fi
fi
show_progress "Configuring Environment...      " "100" "[██████████]"
echo -e "\r${GREEN}✅ Environment Setup Completed (.env configured on Port 8080)! ${RESET}\n"
sleep 0.5

echo -e "${BLUE}====================================================================${RESET}"
echo -e "${GREEN}🎉 CONGRATULATIONS! ZettaPanel V1 has been installed successfully! 🎉${RESET}"
echo -e "${BLUE}====================================================================${RESET}\n"

echo -e "${WHITE}📌 TO CUSTOMIZE PANEL SETTINGS (Optional):${RESET}"
echo -e "${CYAN}   nano .env${RESET}\n"

echo -e "${WHITE}🚀 TO START THE PANEL ON PORT 8080:${RESET}"
echo -e "${CYAN}   python3 zetta.py${RESET}\n"

echo -e "${PURPLE}💡 Enjoy your new Dark & Light Cloud Engine! — IamGunpoint${RESET}\n"
