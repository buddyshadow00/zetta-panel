# ZETTA CONTROL PANEL V1

Run Vps Control panel with Docker using simple commands.

---

## 📥 Install files and setup
```bash
git clone https://github.com/IamGunpoint/ZettaPanel_V1.git
cd ZettaPanel_V1
sudo apt install python3-pip -y
pip install -r requirements.txt
mv env.properties .env
```

---

## 📌 Update Packages Using These Commands:
Click on the copy button to copy each command! ⬇️

```
sudo su
```

```
sudo apt update
```

```
sudo apt install docker.io
```

```
docker
```

```
pwd
```

---

## 🚀 Final Step

### ▶️ Configure bot settings
```
nano .env
```

### ▶️ Start Project
```
python3 zetta.py
```

---

## ⭐ Contribute
- Star ⭐ the repo  
- Fork 🍴 the project  
- Contribute 🔧 via pull requests  

---

## 📞 Discord: 
[![Nightt.jss](https://discord.com/users/969258536557244537)
